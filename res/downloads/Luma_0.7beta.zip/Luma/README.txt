This is the beta release of Luma v0.7 - A BMG editor for Super Mario Galaxy.
It is a .NET 6 based C# program. It'll probably shit itself on anything but Windows 
since I used WinForms to make the GUI.
If you find any issue, bug, crash (in this or in-game), please contact me (Bussun#0586
on Discord).

Keep in mind this is a BETA so I can't guarantee it is bug-free. ALWAYS have a backup
of your files in case anything goes wrong.
I hope you'll find it convinient and easy!

Features:
-Editing text and item properties
-Adding new entries
-Escape sequences supported
-No need to extract your arc file anymore
-Has a GUI (not as pretty as it could be tho)
-Update checker to see if you are missing out on something!
-Maybe more

More features coming soon!
