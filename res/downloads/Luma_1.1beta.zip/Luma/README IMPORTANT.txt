This is the 1.1 beta release of Luma - A BMG editor for Super Mario Galaxy.
It is a .NET 6 based C# program. It'll probably shit itself on anything but Windows 
since I used WinForms to make the GUI.
If you find any issue, bug, crash (in this or in-game), please contact me (Bussun#0586
on Discord). 

!!! I'M 99% SURE THERE WILL BE ISSUES WITH THIS BUILD, PLEASE REPORT EVERY EXCEPTION YOU GET !!!
!!!				ESPECIALLY WITH LITTLE ENDIAN FILES			     !!!

ALWAYS have a backup of your files in case anything goes wrong. (It makes one when you open your arc file)
I hope you'll find it convinient and easy!

Features:
-Editing text and item properties
-Adding new entries
-Escape sequences supported
-No need to extract your arc file anymore
-Has a GUI (not as pretty as it could be tho)
-Update checker to see if you are missing out on something! (Available on the about window)
-Little endian support [WIP] [PLEASE REPORT ANY ISSUE/BUG/ANYTHING UNEXPECTED]
-Maybe more

More features coming soon!
