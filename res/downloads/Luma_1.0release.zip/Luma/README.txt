This is the 1.0 release of Luma - A BMG editor for Super Mario Galaxy.
It is a .NET 6 based C# program. It'll probably shit itself on anything but Windows 
since I used WinForms to make the GUI.
If you find any issue, bug, crash (in this or in-game), please contact me (Bussun#0586
on Discord).

Keep in mind this is provided as-is I can't guarantee it is bug-free. ALWAYS have a backup
of your files in case anything goes wrong. (It makes one when you open your arc file)
I hope you'll find it convinient and easy!

Features:
-Editing text and item properties
-Adding new entries
-Escape sequences supported
-No need to extract your arc file anymore
-Has a GUI (not as pretty as it could be tho)
-Update checker to see if you are missing out on something! (Available on the about window)
-Maybe more

More features coming soon!
